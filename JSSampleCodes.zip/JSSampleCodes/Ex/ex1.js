 // Find the common emelements of a two data set

 console.log("Helow JS")

function printCom() {
    const a1=[2,3,4,65,22,13,45,6,7]
    const a2=[12,13,4,15,22,13,41,16,17]    
    for(let i=0;i<a1.length;i++){
        for(let j=0;j<a2.length;j++){
            if(a1[i]==a2[j]){
               console.log("Common element of two arrays are :"+a1[i])
            }
        }
    }    
}

//As arrow funtion
var printCommontElement=() => {
    const a1=[2,3,4,65,22,13,45,6,7]
    const a2=[12,13,4,15,22,23,41,16,17]    
    for(let i=0;i<a1.length;i++){
        for(let j=0;j<a2.length;j++){
            if(a1[i]==a2[j]){
               console.log("Common element of two arrays are :"+a1[i])
            }
        }
    }    
}

printCommontElement()

printCom()

// This is how to remove duplicates while finding the common emelements of a two data set

function printUniqueCommonElements() {
    const a1=[2,3,4,65,22,13,45,6,7];
    const a2=[12,13,4,15,22,13,41,16,17];  
    const commonNumbers=new Set();  
    for(let i=0;i<a1.length;i++){
        for(let j=0;j<a2.length;j++){
            if(a1[i]==a2[j]){
                commonNumbers.add(a1[i]);               
            }
        }
    }  
    console.log(commonNumbers);  
}

printUniqueCommonElements(); 


