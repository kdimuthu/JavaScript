const number=2222244.98
//This is how to remove decimal from a number
const decimal = Math.trunc(number)
const replacedNumber=number.toString().replace(2,"")
console.log(replacedNumber)

const strinNumber="2222"
//This is how to convert string in to a integer
const intNumber=parseInt(strinNumber)
console.log(intNumber)

//This is how to remove space from a string
const myName= " AP "
const nameRemovingSpaces=myName.trim()
//console.log(myName)
console.log(nameRemovingSpaces)

//This is how to check not equal
const val=0
const val1=1
//This is how to use or equal
if(val!=0 || val1!=0){
console.log("Vale is not zero")
}
else{
    console.log("Vale is zero")
}
if(val!=0 && val1!=0){
console.log("Vale is not zero with and condition")
}
else{
    console.log("Vale is zero")
}

//This is how to remoe charaters and special characters from a string

const id="Bet BETSS-055230 Successfully Placed!"
const newId=id.replace(/[^0-9]/g,"")
console.log(newId)

//This is how to remove characters and remove last 2 registeres
const num="LKR LKR 180.00"
const newNum=num.replace(/[^0-9]/g, "")
console.log(newNum)

//Remove last characters 

const str = "LKR LKR 180.00";
const newStr=str.replace(/[^0-9]/g, "")
const str1 = newStr.substring(0, newStr.length - 2);
console.log(str1);

console.log("Convert string to integer")
const a="1234"

const b="4312"
const c=a+b
console.log(c)

const x = parseInt("c", 10)

console.log(x)
