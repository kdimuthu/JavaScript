//Relational or Comparision operators
// > - more than
var result =6>2
console.log(result)

// < - less than
var resultLessThan = 4<87
console.log(resultLessThan)

// >= more than equal

var resultMoreThanOrEqual = 4>=4
console.log(resultMoreThanOrEqual)

//<= - less than or equal
var resultLessThanOrEqual = 5<=5
console.log(resultLessThanOrEqual)

//equalit operators
var x=1
console.log(x=='1') // loss comparison
console.log(x==='1') // strict comparision