//Concatination and Intepolation

var price=20
var itemName="Cup"

//Concatination
var msgToPrintConcatination="The price for your "+itemName+" is "+price+" rupees"
console.log(msgToPrintConcatination)

//Intepolation
var msgToPrintIntepolation=`The price for your ${itemName} is ${price} rupees`
console.log(msgToPrintIntepolation)