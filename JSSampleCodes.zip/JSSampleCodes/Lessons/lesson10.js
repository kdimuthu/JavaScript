//Arthmetic Operators

let a=5
let b=3

//Addition
console.log("Addition is "+(a+b))
//Subtraction
console.log("Substraction is "+(a-b))
//Multiplication
console.log("Multiplication is "+(a*b))
//Exponentiation 
console.log("Exponentiation is "+(a**b))
//Division
console.log("Division is "+(a/b))
//Modulus (Division Remainder)
console.log("Modulus is "+(a%b))
//Increment
let c=a++
console.log("Increment is "+c)
//Decrement
let d=a--
console.log("Decrement is "+d)