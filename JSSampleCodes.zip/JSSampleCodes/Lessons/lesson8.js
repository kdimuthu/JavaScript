//Declarative funtions

helloOne()
function helloOne(){
    console.log("Funtion type 1")
}

//Expression futions
//helloOne() // This syntax can be called either top or bottom of the funtion

//Anoymus funtion
var helloTwo=function(){
    console.log("Funtion type 2")
}
helloTwo()

//ES6 funtion syntax or arrow funtion
var helloThree=()=>{
    console.log("Funtion type 3")
}
helloThree()

//Funtion with argument
function printName(name,age){
    console.log("Name is "+name+" Age is "+age)
}
printName("Dimuthu",34)

//Funtion with Return
function multipleByTwo(number){
    var result=number*2
    return result
}
var myResult=multipleByTwo(20)
console.log("My result is "+ myResult)

//To import funtions, you need to add type = module setting in package.json
//Import funtion 

printAge(65)
import { printAge } from './Helper/printHelper.js' 

//Import everything
import * as helper from './Helper/printHelper.js'
helper.printAge(10)

//This is how to implement funtion
function printMyName(){
    console.log("This is via a funtion: Dimuthu")
}
//This is how to call the funtion
printMyName()

function addTwoNumber(x,y){
    return x+y
    
}

let a=addTwoNumber(3,4)
console.log("Return funtions "+a)

//Fution to conbert fahrenheit to celsius

function convertfahrenheitToCelsius(fahrenheit){
    return (5/9)*(fahrenheit-32)
}

let temporatureInCelsius=convertfahrenheitToCelsius(100)
console.log("Celsius "+temporatureInCelsius)
