//This is how to comment in JS
console.log("Hellow JS")

//Variables using var
var firstName="Dimuthu"
console.log("First name is "+firstName)

//Variables using let
let lastName="Ramachandra"
console.log("Last name is "+lastName)

//Variable usign const
const price1 = 5;
const price2 = 6;
const total=price1+price2
console.log("Here are the constant variables "+total)

//Print first variable
console.log(firstName)
//Print both variable
console.log("Full name is "+firstName+" "+lastName)

var a, b, c
a=4,b=7,c=6
console.log("Whole value is "+a+b+c)

//data types
var city="Colombo" //string
var code=5 //number
var isHeMarried=false //boolean
var yearsInMarraiage=null //null
var numberOfCars=undefined //undefined

//Block Scope
{
let x=4
}
//console.log("X is "+ x) - you can declrate variable with let out side the block code

{
    var y=4
}
console.log("Y is "+ y) 

//Let Hoisting

carName = "Volvo"
var carName

//you cant do below in JS

/* vanName = "Saab"
let vanName="dfd" */

