//funtion
export function printAge(age){
    console.log(age)
}

//Class with export keyword
export class CustomerDetails{

    //Method
    printFirstName(firstName){
        console.log(firstName)
    }

    printLastNanme(secondName){
        console.log(secondName)
    }
}

//Class without export keyword
class StudentDetails{

    //Method
    printAge(age){
        console.log(age)
    }

    //If you want to get below on top of the method , just type /** and press enter
    
   /**
    * 
    * @param {*} studentName 
    */
    printName(studentName){
        console.log(studentName)
    }
}

//When you doesnt want to create a class with export keyword, you have to create object here

export const objStudentDetails= new StudentDetails()