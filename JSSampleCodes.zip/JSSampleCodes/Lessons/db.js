import mysql from 'mysql';

var con = mysql.createConnection({
    host: "10.20.30.2",
    user: "betssuser",
    password: "Passw0rd@1"
  });

/*   con.connect(function() {  
    console.log("Connected!");
  }); */

  con.connect(function() {
   
    console.log("Connected!");    
    con.query("", function (result) {      
      console.log("Result: " + result);
    });
  });

  
