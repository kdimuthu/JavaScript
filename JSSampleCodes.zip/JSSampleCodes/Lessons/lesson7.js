//Loops

//for loop(for i loop)
for(let i=0;i<5;i++){
    console.log("This is a loop: "+i)
}

//for of loop
var cars=["Volvo","Toyota","Honda"]

for(let car of cars){
    console.log(car)
    if(car=="Toyota"){
        break
    }
}

//ES6 syntax for each loop
cars.forEach(car => {
    console.log("This is using a for each loop: "+car)
});