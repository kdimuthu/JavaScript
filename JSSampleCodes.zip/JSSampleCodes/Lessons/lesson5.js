//Logical Operators

//Logical AND
var x=true
var y=true
var finalStatus=x && y
console.log("It is elegibal "+finalStatus)

//Logical OR
var a=false
var b=true
var finalStatus=x || y
console.log("It is elegibal for logical or "+finalStatus)

//Logical NOT
console.log(!true)
console.log(6!==10)