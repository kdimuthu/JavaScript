//Strings

let text="Dimuthu6473&*&8ramachandra "

//Get the legnth of string

console.log("Lenght of string is "+text.length)

let text1="Dimuthu\
            Ramachandra"

console.log("Lenght of string is "+text1)

//String slice
let part=text.slice(2,6)
console.log("Slicing "+part)

//Substring
let part1=text.substring(2,6)
console.log("Substring "+part1)

//Replacing 
let part3=text.replace("Dimuthu","kenath")
console.log("replacing "+part3)

//converte to upper case
let part4=text.toUpperCase()
console.log("Upercase "+part4)

//converte to lower case
let part5=text.toLowerCase()
console.log("Lowercase "+part5)

//concat
let text2 = "Hello";
let text3 = "World";
let part6=text2.concat(text3)

console.log("concat "+part6)

//Trim
let part7=text.trim()
console.log("Trim "+part7)

//Pad Start
let number = 5;
let text5=number.toString()
let part8=text5.padStart(6,"1")
console.log("PadStart "+part8)

//Pad End

//Chart At
let part9=text.charAt(2)
console.log("Char At "+part9)

//char Code At
let part10=text.charCodeAt(0)
console.log("Char Code At "+part10)

//Split
let part11=text.split("r")
console.log("Split "+part11)

