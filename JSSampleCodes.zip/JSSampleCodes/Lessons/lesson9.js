

import { CustomerDetails } from "./Helper/printHelper.js";

//Ceating a object of class customer detals
var objCustomerDetails = new CustomerDetails()

//Calling method in customer details class
objCustomerDetails.printFirstName("Dimuthu")
objCustomerDetails.printLastNanme("Ramachandra")

//Second Method
//importing the instance insted of importing entire class
import { objStudentDetails } from "./Helper/printHelper.js";
objStudentDetails.printAge("33")
objStudentDetails.printName("Kenath")
