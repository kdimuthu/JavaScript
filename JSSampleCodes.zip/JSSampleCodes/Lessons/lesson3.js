//Objects
const customer = {

    firstName:'Dimuthu',
    lastName:'Ramchandra',
    age:34,
    //This is how to add an array to a object
    car:["Volvo","Toyota","Honda"]

}
//This is to enter whole object
console.log(customer)
//This is to acces only a particular item
console.log("Age is "+customer.age)
//Dot notation
customer.firstName="Kenath"
//Bracket notation
customer[`lastName`]="Rama"
console.log(customer)

//Arrays
var car=["Volvo","Toyota","Honda"]
//This is how we acces all the element in array
console.log(car)
//This is how to acces a particular item using index
console.log("First element of array is "+car[0])
console.log("Second element of array is "+car[1])
//This is how to change the element in array
car[2]="BMW"
console.log("Thirs element of array after changing is "+car[2])

console.log(customer.car[0])

//Constant arrays
const cars = ["Saab", "Volvo", "BMW"]
//Prinint Array
console.log("Constant array is "+cars)
// You can change an element:
cars[0] = "Toyota"
//Prinint Array
console.log("Constant array after changing the element "+cars)
// You can add an element:
cars.push("Audi")
//Prinint Array
console.log("After pushing element "+cars)